
(void)SetWDO(0, WDO0);
(void)SetWDO(1, WDO1);
(void)SetWDO(2, WDO2);
(void)SetWDO(3, WDO3);
(void)SetWDO(4, WDO4);
