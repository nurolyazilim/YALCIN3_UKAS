Date and time:     Fri Mar 05 15:56:13 2021
Computer name:     DESKTOP-5R73RFV
User name:         yazilim1
Windows version:   6.2.9200.2 
Version of vt3:    7.6.3.2-stable

Project:           C:\Users\yazilim1\Desktop\nmsGit\YALCIN3_UKAS\YALCIN_UKAS\UKAS.vt3
Project version:   a01
Device:            GIGA
Source address:    13

File name        Size (bytes)
.\xxx_a01_giga.s19    5576802

End of manifest
