Date and time:     Fri Mar 05 15:55:26 2021
Computer name:     DESKTOP-5R73RFV
User name:         yazilim1
Windows version:   6.2.9200.2 
Version of vt3:    7.6.3.2-stable

Project:           C:\Users\yazilim1\Desktop\nmsGit\YALCIN3_UKAS\YALCIN_UKAS\UKAS.vt3
Project version:   a01
Device:            MC2M/CPU0
Source address:    5

File name        Size (bytes)
.\xxx_a01_cpu00.s19    1942954

End of manifest
