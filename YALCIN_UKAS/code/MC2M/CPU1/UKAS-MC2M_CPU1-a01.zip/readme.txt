Date and time:     Wed Aug 26 09:36:55 2020
Computer name:     BATUHAN
User name:         Mert
Windows version:   6.2.9200.2 
Version of vt3:    7.6.3.2-stable

Project:           C:\Users\Mert\Desktop\workspace\YALCIN_UKAS\YALCIN_UKAS\UKAS.vt3
Project version:   a01
Device:            MC2M/CPU1
Source address:    133

File name        Size (bytes)
.\xxx_a01_cpu01.s19     629140

End of manifest
