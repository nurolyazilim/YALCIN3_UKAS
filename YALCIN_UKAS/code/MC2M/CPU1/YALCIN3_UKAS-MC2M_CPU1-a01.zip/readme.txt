Date and time:     Thu Jan 09 16:53:37 2020
Computer name:     DESKTOP-VH7U36D
User name:         Mert
Windows version:   6.2.9200.2 
Version of vt3:    7.6.3.2-stable

Project:           C:\Users\Mert\Desktop\ARAÇ_YAZILIMLARI_SYNC\YALCIN3_UKAS\20200108\YALCIN3_UKAS.vt3
Project version:   a01
Device:            MC2M/CPU1
Source address:    133

File name        Size (bytes)
.\xxx_a01_cpu01.s19     629140

End of manifest
