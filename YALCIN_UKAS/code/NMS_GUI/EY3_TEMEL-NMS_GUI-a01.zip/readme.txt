Date and time:     Mon Dec 02 10:59:48 2019
Computer name:     DESKTOP-VH7U36D
User name:         Mert
Windows version:   6.2.9200.2 
Version of vt3:    7.6.3.2-stable

Project:           C:\Users\Mert\Desktop\ARAÇ_YAZILIMLARI_SYNC\YALCIN3_UKAS\26072019\SW_YALCIN\EY3_TEMEL.vt3
Project version:   a01
Device:            NMS_GUI
Source address:    50

File name        Size (bytes)
.\1eyiii_difflock_bos1.png      17984
.\1eyiii_difflock_hepsi1.png      18262
.\1eyiii_difflock_orta1.png      18128
.\1eyiii_difflock_orta_arka1.png      18183
.\28a.png              1384
.\admin_off.png        4446
.\admin_on.png         4421
.\arial.ttf          367112
.\arialb.ttf         352224
.\bg2.png            396658
.\button2_available.png        483
.\button2_unavailable.png        493
.\CPU.dat               578
.\difflockdropbox_bg.png     343990
.\DimScreenMod3.exe     423918
.\dropbox_high.png      10319
.\dropbox_high_white.png       3610
.\dropbox_low.png       8943
.\dropbox_low_white.png       3223
.\dropbox_neutral.png        925
.\dropbox_neutral_white.png        910
.\extra_files_readme.txt        135
.\FontReg-32.exe       6144
.\icudt51.dll      22378434
.\icuin51.dll       3369922
.\icuuc51.dll       1978690
.\libgcc_s_dw2-1.dll     544817
.\libstdc++-6.dll     989805
.\libwinpthread-1.dll      73901
.\LOG_WinLoader.txt         60
.\memory.ini          18544
.\nurollogo.png        4450
.\Qt5Core.dll       4389376
.\Qt5Gui.dll        4450304
.\Qt5Widgets.dll    6146560
.\send_off_40.png       2588
.\send_on_40.png       3152
.\TaskKeyHook.dll      13824
.\vt3_app.exe        676922
.\WinLoaderdll.dll     126976
platforms\qminimal.dll      46080
platforms\qoffscreen.dll     576512
platforms\qwindows.dll    1232896

End of manifest
